/**
 * Book entity, used for filtering as well.
 */
export class Book {

    
    /**
     * @type {string} title The title of the flight.
     */
    cmpSearch: String;

    /**
     * @type {string} title The title of the flight.
     */
    arrLocSearch: String;

     /**
     * @type {string} title The title of the flight.
     */
    deptLocSearch: String;

  
    /**
     * @type {number} arrive date.
     */
    arrvDate: number;

    
  
   
  }